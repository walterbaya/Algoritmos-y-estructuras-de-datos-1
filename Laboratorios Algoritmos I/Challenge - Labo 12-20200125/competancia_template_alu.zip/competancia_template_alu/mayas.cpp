#include "mayas.h"
/* Utiles */
tuple<string,string> leerEntrada(string filename){
	string s1,s2;
	return make_tuple(s1,s2);
}

int leerSalida(string filename){
	int s;
	return s;
}
/* Utiles */


/* RESOLUCION ALUMNOS */
int posiblesApariciones(string w, string s){
	int count = 0;

	return count;
}
/* RESOLUCION ALUMNOS */