//
// Created by Pablo on 22/11/2017.
//

#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include "robotitos.h"

using namespace std;

/* UTILES */
int leerDatos(string s, int& A, int& B, int& T, vector<int>& X, vector<int>& Y, vector<int>& W, vector<int>& S) {
    int res = 0;
    return res;
}

int leerTiempoReal(string s){
    int rta = -2;
    return rta;
}
/* UTILES */

/* RESOLUCION ALUMNOS */
int calcularTiempoRecoleccion(int A, int B, int T, vector<int> X, vector<int> Y, vector<int> W, vector<int> S) {
    int tiempo = 0;
    return tiempo;
}
/* RESOLUCION ALUMNOS */
