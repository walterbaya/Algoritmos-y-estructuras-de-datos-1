#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include "libros.h"

using namespace std;

/* Utiles */
vector<int> leerEntrada(string filename, int & s){
	vector<int> v;
	return v;
}

long leerRta(string filename){
    long rta = -10;
    return rta;
}
/* Utiles */


/* RESOLUCION ALUMNOS */
long caminoMasCorto(std::vector<int> p, int s) {
	return -1;
}
/* RESOLUCION ALUMNOS */