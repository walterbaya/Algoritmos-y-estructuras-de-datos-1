#include "vectores.h"
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
using namespace std;

int main() {
    holaModuloVectores(); // función definida en vectores.cpp
    return 0;
}
