#include <string>
#include <vector>
#include "risas.h"
#include <iostream>
#include <fstream>

using namespace std;

/* Utiles */
vector<char> leerDatos(string s) {
    vector<char> vec;
    return vec;
}

int leerLargoReal(string filename){
    int val = -1;
    return val;
}
/* Utiles */

/* RESOLUCION ALUMNOS */
int risaMasLarga(vector<char> s)
{
    int largo = 0;
    return largo;
}
/* RESOLUCION ALUMNOS */
